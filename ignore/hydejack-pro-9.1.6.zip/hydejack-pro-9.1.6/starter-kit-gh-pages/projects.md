---
layout: projects
title: Projects
show_collection: projects
description: >
  How people are using Hydejack in the real world. 
  This page is built using the `projects` layout* that you can use yourself to build a portfolio.
no_groups: true
---
